/* Desktop compatibility layer for Xuper Hydra PC.
   Replaces the LG webOS Luna bridge with the local Node service bundled for Electron. */
(function () {
  'use strict';
  var params = new URLSearchParams(window.location.search || '');
  var serviceBase = params.get('service') || 'http://127.0.0.1:8910';
  serviceBase = String(serviceBase).replace(/\/+$/, '');
  var info = {
    modelName: 'Windows PC',
    platformVersion: 'Desktop',
    platformVersionMajor: 3,
    platformVersionMinor: 0,
    screenWidth: (window.screen && window.screen.width) || window.innerWidth || 1280,
    screenHeight: (window.screen && window.screen.height) || window.innerHeight || 720,
    uhd: false,
    manufacturer: 'PC'
  };

  function serviceRequest(uri, options) {
    options = options || {};
    var method = String(options.method || '').replace(/^\/+/, '');
    if (!method) {
      var parts = String(uri || '').split('/');
      method = parts[parts.length - 1] || '';
    }
    var controller = new AbortController();
    var timeoutMs = Math.max(1000, Number(options.timeout) || 20000);
    var timeout = setTimeout(function () { controller.abort(); }, timeoutMs);
    var payload = options.parameters || {};
    var url = serviceBase + '/' + encodeURIComponent(method) + '?q=' + encodeURIComponent(JSON.stringify(payload));
    fetch(url, {
      method: 'GET',
      cache: 'no-store',
      credentials: 'omit',
      signal: controller.signal
    }).then(function (response) {
      if (!response.ok) throw new Error('Servicio local HTTP ' + response.status);
      return response.json();
    }).then(function (result) {
      clearTimeout(timeout);
      if (result && result.returnValue === false) {
        if (typeof options.onFailure === 'function') options.onFailure(result);
      } else if (typeof options.onSuccess === 'function') {
        options.onSuccess(result || { returnValue: true });
      }
      if (typeof options.onComplete === 'function') options.onComplete(result || {});
    }).catch(function (error) {
      clearTimeout(timeout);
      var failure = {
        returnValue: false,
        errorCode: -1,
        errorText: error && error.name === 'AbortError' ? 'Tiempo de espera agotado en el servicio local' : String(error && error.message || error)
      };
      if (typeof options.onFailure === 'function') options.onFailure(failure);
      if (typeof options.onComplete === 'function') options.onComplete(failure);
    });
    return {
      cancel: function () { clearTimeout(timeout); controller.abort(); }
    };
  }

  function deviceInfo(callback) {
    var result = Object.assign({}, info);
    if (typeof callback === 'function') callback(result);
    return result;
  }
  var systemInfo = {
    version: 'Desktop',
    country: (navigator.language || 'es').split('-').pop(),
    timezone: (Intl.DateTimeFormat().resolvedOptions().timeZone || '')
  };
  function platformBack() {
    try { window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (_) {}
    return true;
  }

  window.PalmSystem = {
    identifier: 'com.webosflux.xuptertv.pc',
    deviceInfo: JSON.stringify(info),
    platformBack: platformBack,
    stageReady: function () {},
    launchParams: '{}'
  };
  /* app.js checks for this marker before invoking webOS.service.request. */
  window.PalmServiceBridge = function DesktopPalmServiceBridge() {};
  window.webOS = {
    service: { request: serviceRequest },
    deviceInfo: deviceInfo,
    systemInfo: systemInfo,
    platformBack: platformBack,
    fetchAppId: function () { return 'com.webosflux.xuptertv.pc'; },
    fetchAppInfo: function (callback) {
      var value = { id: 'com.webosflux.xuptertv.pc', title: 'Xuper Hydra para PC', version: '3.0.9-pc' };
      if (typeof callback === 'function') callback(value);
      return value;
    },
    fetchAppRootPath: function () { return ''; },
    keyboard: { isShowing: function () { return false; } },
    platform: { tv: false, desktop: true, unknown: false }
  };
  window.webOSTV = { platformBack: platformBack };
  window.XUPER_DESKTOP = true;
  window.XUPER_DESKTOP_SERVICE = serviceBase;
  console.info('[Xuper Hydra PC] Puente de escritorio activo:', serviceBase);
})();
